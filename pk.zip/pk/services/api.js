const api = [
	{
    "disc": "100000000000",
    "song": "orignal_song_praveen",
    "name": "video",
    "uid": "tY5N55cevCRgBQwfVD73RGVnBYC2",
    "username": "praveen",
    "video": "https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/videos%2F55c2f0d8-fda8-473b-8839-1533e088de90.mp4?alt=media&token=7d2e78f7-b6b5-4b0a-9bfb-8a13ef15ea11",
  }
]

export default api
