import React, {Component} from 'react';
import { ImageBackground,TouchableOpacity,StyleSheet, Text, View, SafeAreaView, Image, ScrollView } from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import styled from 'styled-components/native';
/*import Poster from './poster.js';
*/const goToFav = () => {
      alert("Favrate");
	  }
      const goToGrid = () => {
      alert("Grid view");
	  }
      const goToLove = () => {
      alert("Loved videos");
	  }
export default class Profile extends Component<Props> {
render(){
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView showsVerticalScrollIndicator={false}>
                <View style={{ alignSelf: "center" }}>
                    <View style={styles.profileImage}>
                        <Image source={require("../assets/profile-pic.jpg")} style={styles.image} resizeMode="center"></Image>
                    </View>
                </View>
                <View style={styles.infoContainer}>
                    <Text style={[styles.text, { fontWeight: "200", fontSize: 18 }]}>@{this.props.username}</Text>
                    <Text style={[styles.text, { color: "#AEB5BC", fontSize: 14 }]}>TikToker</Text>
                </View>
                <View style={styles.statsContainer}>
                    <View style={styles.statsBox}>
                        <Text style={[styles.text, { fontSize: 18 }]}>483</Text>
                        <Text style={[styles.text, styles.subText]}>Posts</Text>
                    </View>
                    <View>
                        <Text style={[styles.text, { fontSize: 18 }]}>{this.props.follower}</Text>
                        <Text style={[styles.text, styles.subText]}>Followers</Text>
                    </View>
                    <View style={styles.statsBox}>
                        <Text style={[styles.text, { fontSize: 18 }]}>{this.props.following}</Text>
                        <Text style={[styles.text, styles.subText]}>Following</Text>
                    </View>
                </View>
                <View>
                <Button>
                <Text style={[styles.text, { color: "#ffffff", fontWeight: "300" }]}>
                Follow</Text>
                </Button>
			        <Menu>
                    <TouchableOpacity style={{ marginLeft: 5 }} onPress = {goToFav}>
				        <Icon resizeMode='contain' source={require('../assets/icons/fav.png')} />
                        </TouchableOpacity>
			        </Menu>
                </View>
                <View>
                <Menu>
                    <TouchableOpacity style={{ marginTop: 70 ,marginLeft: -350 }} onPress = {goToGrid}>
				        <Icon style={{ width:23 }} resizeMode='contain' source={require('../assets/icons/grid.png')} />
                        </TouchableOpacity>
			        </Menu>
                    <Menu>
                    <TouchableOpacity style={{ marginLeft: 45,marginTop: -3 }} onPress = {goToLove}>
				        <Icon style={{ width:29 }} resizeMode='contain' source={require('../assets/icons/love.png')} />
                        </TouchableOpacity>
			        </Menu>
                </View>
                <View><Icon style={{ width:350,marginTop:-20,marginLeft:5 }} resizeMode='contain' source={require('../assets/icons/line.png')} /></View>
                <View>
                
                </View>
            </ScrollView>
        </SafeAreaView>
    );
    }
}
const Separator = styled.View`
	width: 1px;
	height: 13px;
	background-color: #d8d8d8;
	opacity: 0.6;
`
const Button = styled.View`
	width: 130px;
	height: 36px;
    color:white;
	background: #ff0090;
	justify-content: center;
	align-items: center;
    margin-left:100px;
    margin-top:12px
`
const Menu = styled.View`
	margin-top:-38px;
    margin-left:150px;
	align-items: center;
`
const Icon = styled.Image`
	height: 40px;
`
const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop:20,
        backgroundColor: "#FFF"
    },
    text: {
        color: "#52575D"
    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 12,
        color: "#AEB5BC",
        textTransform: "uppercase",
        fontWeight: "500"
    },
    profileImage: {
        width: 120,
        height: 120,
        borderRadius: 80,
        overflow: "hidden"
    },
    add: {
        backgroundColor: "#41444B",
        position: "absolute",
        top:100,
        left: 40,
        width: 35,
        height: 35,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 0
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: 12
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 343,
        height: 650,
        borderRadius: 12,
        overflow: "hidden",
        marginTop:10,
        marginHorizontal: 10
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },

    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    gridView: {
    marginTop: 20,
    flex: 1,
  },
  itemContainer: {
    justifyContent: 'flex-end',
    borderRadius: 5,
    padding: 10,
    height: 150,
  },
  itemName: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
  },
  itemCode: {
    fontWeight: '600',
    fontSize: 12,
    color: '#fff',
  },
  sectionHeader: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
    alignItems: 'center',
    backgroundColor: '#636e72',
    color: 'white',
    padding: 10,
  },
});