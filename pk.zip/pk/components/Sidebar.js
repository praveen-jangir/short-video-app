import React from 'react'
import styled from 'styled-components/native'
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { TouchableOpacity, Text,StyleSheet, View, Animated, Image, Easing,Share } from 'react-native';
import firebase from '../screen/firebase.js';
const dbh = firebase.firestore();
const Container = styled.View`
	width: 60px;
	height: 100%;
	padding-bottom: 59px;
	justify-content: flex-end;
`
const Menu = styled.View`
	margin: 9px 0;
	align-items: center;
`
const User = styled.View`
	width: 48px;
	height: 48px;
	margin-bottom: 13px;
`
const Avatar = styled.Image`
	width: 100%;
	height: 100%;
	border-radius: 48px;
	border-width: 2px;
	border-color: #ffffff;
`
const Icon = styled.Image`
	height: 40px;
`
const Count = styled.Text`
	color: #fff;
	font-size: 12px;
	letter-spacing: -0.1px;
`
const SoundBg = styled.View`
	background: #1f191f;
	width: 50px;
	height: 50px;
	border-radius: 50px;
	justify-content: center;
	align-items: center;
	margin-top: 20px;
`
const Sound = styled.Image`
	width: 25px;
	height: 25px;
	border-radius: 25px;
`
function LikeUp(uid,vid) {
  const subscriber = dbh
      .collection('user')
      .doc(uid)
      .onSnapshot(documentSnapshot => {
          dbh.collection("like").add({
          uid: uid,
          vid: vid,
      })
      });
}

export default class Sidebar extends React.Component<props> {
  constructor(props) {
  	super(props);
  	const vid = props.vid;
  	const uid = props.uid;
  	const download = props.download;
    this.RotateValueHolder = new Animated.Value(0);
    this.state = {
          color:"#ffffff",
          count:0,
          vid:vid,
          uid:uid,
          comment:0,
          download:download,
          Avatar:'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAARVBMVEWVu9////+QuN6Rud6Mtt2nxuTg6vWavuDp8Pi80+rJ2+6fweLR4fDN3u/3+vzl7vexzOfa5vO/1evy9vusyeW2z+ju8/mJFiEAAAAGxUlEQVR4nO2d67ajKBCFFfCGJmqief9HbYnJykVNq2ziNofvx0yv6e6zsgeoogrYCQKPx+PxeDwej8fj8VAhRYcU/b+2/jBYpJRK5FWmi7qO47iuC51VuVDdf9/6oyGQQkU6PoZDjrGO1O5HU4gsHhH3IM6E2PpDrkeq5rO8m8hK7XMgpcrOM/Rd52u2Q41StWNrb1JjuzeNMr8s0Ge45LuSqPRCfQattv7Y85HpCoFhmO5lFGW+Sp9hHzNVRKsFhmG0g+QoGwuBYdjQS5Q2I3gdRfaJmlgKDMNkawmfUXO3MdOcqeepqq0FhmFNnBdlBRAYhhXvUhQQgWFIO09FAVJYsEq0j6N3SOOpQISZnppzEHFDSDqIsFVooFyJCigwDAlzosygCjO+nChKqMKSbxAlVGAYbq1nAHiSEk5TYDLsoUuJakl3dA5HtoWITPc9ZElftnCFLddCFAe4wgPXQpRzDpmWEXONIaA/886ZK9RgN6U9XAoDBwq3lvTK+qOKafKtRb1g2+keI9pa1DOgNuIrVE1FBwmfLOXDKwsDVXXhFXqFO1D485EmsDvaHqfZWtQz1mfbY3Cdd+NLfLYiH3Vy+AxXBfz71dPvV8C/38WAHq31kB2wyRNc4YlrDB2kfKqEH/yBnreDdMEVSrtQs+5a8DQpV6BxEEzJQulfOCGFd0y5uqUGdKhhCzT4uxhsy7BTuOYRyTSaTyG4zKdq6d/4+VtfgUAWUDHfJAWXF2yFxQ2gQrZtd49a+uRwmgvjMuymKS5faM5J+vs32QOFqqBSzkkKrC/46oo7P/9mBlUG010tfQJTJPKVhg8UooQivMT+BKLAYCwrHgASBm2quGE/iNxDCFiJ3KvQYBtOmQNpj2VOpGsEjyBsXl4cdyDQzjaiod2RPqPWz9OCPsz0rL62QHY54QNrS2HWwnfIyqW4j0XYs6oW5q17x1DLm6en3SzCnsUS9yawS/zLLtW2e0j1byxyxNqDA9YQGcytM8odGZnKl7FQ80Jq9rIEqR1NhTq9XoMRwf+feNfB619JT4p1ysrrwcVbE0IknzXWyaucaxtEM85aqfLbhvvyNgJC6ql96lnL9z98O78qcjK3T6HaRwvq/P67nXo9DDqlHlHx+H+RtjST1Vghv9ZLx3zw2bo/lLe6iMv0kpZxodt8xCNZ5K/Fc0FhpGzkDYv6dmyDIkXv5W3+OfbB1XCPcDQiXUv4xLg8wwpXuQk3uw1FSpUcplsyx2iZRhV9+FmHZIO4I1X1nx3LW577yH/zZvl1R2xVzehU6Jlm5GLODYBz9c3iQyQzjycG+W7sh8294ZAmX1uPS2q/uvkYJ4RqFlj3fKuGVMuudx2LZvTrHkzmaCZC8RTxVySuOUArD1Wi1C0dmoSoVFIdVhzifOPobf3h0rmsi4PW+lDU5eqHYO6Ppiwa2hhct8Wd2EMsw7GZBNp3bg1OFUKckG1x6aTs5Mn2chw+8oZdzbPDXcogGUKHgwi9q26Ds3vuLmwF1uHooNGBr95aHPnxwe0t1+PIGJMlzhicXA1z8OR+PU4uFhFNUkfT1IWt3nocXH8DvhdB4ODNCfiNqC0O3pi6cKCxAb4Qafakd+B7U7Jl6GAhOrDYsQNu0EOVDQ34jLi1ogFogS5M9ewAO/SA/QQQgD0J6AINPNQ48GOzBXxlmm1HY4AqpNvRGKC7Gices7ZAb01T1fd3oHU+WenUAy2g6PZsBui+jeFQbQhwHVKGUmgwpQyl0GBK1M9/Btjbpzl0egV4BAX01kEC9Olh3JUagOliaykTwPSRJgtgunDyzQcIYN+eQNcrvQPrmVJWFgZYdUHYpOmBtWrgLsgoYG7KhG2oHlgzijXh41K+i6/nwICapTx3od5B3Y3iuqPwDOq+At+pzB3Q6Qztpg22bSPtYRhAfQwH3z+CAmQ3TLvxhm29SftQBlAv6g8oJJ6lGIW/ny3+wK6N5CHJENjTEtpeWw47uBDbv8kbowIekYqcb6KmuBG8oiKGh3kP6oWeDTOQQmYsA5lm0o3piVSB3v4U6qIDlw4SUiWnLUcyPX3BBEQqmW3TIo4z+S3/D2MrpL87lKn+tuFQJ1I0h++oTHUjNvJTEmYsY5e3iY6xGbtNjZSk7CJsdSjxMo/loeqiJod1m+wGM6lwo9mNXJWocb+sDTEyZXMqUis/77Q4NZJP3BNGZxBlRbz0vOocH7KIW9szRmcn1HjQXT4P6fFi/OmiQO1G2zNdlBBSKSXzqGpPxpemjg218ak5tVWUX39XkEQTK2Sn9mou1NP/Mti/Lo/H4/F4PB6Px+P5Hf4BrxJp8oCGoikAAAAASUVORK5CYII=',
      }
      if (vid) {
      	dbh.collection('user')
           .where('uid', '==',this.state.uid)
            .get()
            .then(querySnapshot => {
              querySnapshot.forEach(documentSnapshot => {
                this.setState({Avatar:documentSnapshot.data().Avatar})
              });
            });
        const like = dbh.collection("like").where('vid','==',vid).get().then(like => {
         this.setState({count:like.size});
         const likex=like.size;
         });

        const Comment = dbh.collection("comment").where('uid', '==',vid).get().then(folli => {
         this.setState({comment:folli.size});
         });
    }
     	const user = firebase.auth().currentUser;
  	if (user) {
  		this.setState({uid:user.uid});
  	}
  	else{
  		this.setState({uid:"-1"});
  	}
  }
  Like =()=> {
      this.setState({
        color: "#FF1493",
        count:this.state.count+1,
      })
      LikeUp(this.state.uid,this.state.vid);
  }

  UnLike =()=> {

      this.setState({
        color: "#ffffff",
        count:this.state.count-1,

      })
  }
  componentDidMount() {
    this.StartImageRotateFunction();
  }
  StartImageRotateFunction() {
    this.RotateValueHolder.setValue(0);
    Animated.timing(this.RotateValueHolder, {
      toValue: 1,
      duration: 5000,
      easing: Easing.linear,
      useNativeDriver: true,
    }).start(() => this.StartImageRotateFunction());
  }

    onShare = async () => {
    try {
      const result = await Share.share({
        message:this.state.download,
      });

      if (result.action === Share.sharedAction) {
        if (result.activityType) {
          // shared with activity type of result.activityType
        } else {
          // shared
        }
      } else if (result.action === Share.dismissedAction) {
        // dismissed
      }
    } catch (error) {
      alert(error.message);
    }
  };
  render() {
    const RotateData = this.RotateValueHolder.interpolate({
      inputRange: [0, 2],
      outputRange: ['0deg', '360deg'],
    });
	return (
		<Container>
			<Menu>
				<User>
				<TouchableOpacity onPress={() => this.props.navigation.navigate('Profile',{uid:this.state.uid})}>
					<Avatar resizeMode='cover' source={{uri:this.state.Avatar,}}/>
				</TouchableOpacity>
				</User>
			</Menu>
			<Menu>
           {this.state.color != '#FF1493'? <TouchableOpacity onPress = {this.Like}>
			      <MaterialCommunityIcons name="heart" color={this.state.color} size={52} />
			        </TouchableOpacity>: <TouchableOpacity onPress = {this.UnLike}>
			      <MaterialCommunityIcons name="heart" color={this.state.color} size={52} />
			        </TouchableOpacity> }

				<Count>{this.state.count}</Count>
			</Menu>

			<Menu>
				<Icon
					resizeMode='contain'
					source={require('../assets/icons/comment.png')}
				/>
				<Count>{11}</Count>
			</Menu>

			<Menu>
			<TouchableOpacity onPress={this.onShare}>
				<Icon resizeMode='contain' source={require('../assets/icons/share.png')} />
				</TouchableOpacity>
				<Count>{11}</Count>
			</Menu>

			<Menu>
			<TouchableOpacity onPress={() => this.props.navigation.navigate('Music',{Music:this.state.vid})}>
				<SoundBg>
					<Animated.Image
          style={{
            width: 50,
            height: 50,
            borderRadius:100,
            transform: [{ rotate: RotateData }],
          }}
          source={{
            uri:
              this.state.Avatar,}}/>
				</SoundBg>
				</TouchableOpacity>
			</Menu>
		</Container>
	);
}
}