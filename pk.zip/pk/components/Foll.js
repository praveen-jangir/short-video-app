import React, { useState } from 'react'

import { Dimensions, View,ScrollView,TouchableOpacity,Image } from 'react-native'

import { LinearGradient } from 'expo-linear-gradient'

import styled from 'styled-components/native'
import publicIP from 'react-native-public-ip';

import ViewPager from '@react-native-community/viewpager'
import firebase from '../screen//firebase.js';
import { useRoute } from '@react-navigation/native';

import 'firebase/firestore';

const db = firebase.firestore();

import VideoPlayer from '../components/VideoPlayer'
import Info from '../components/Info'
import Sidebar from '../components/Sidebar'

const { height } = Dimensions.get('window')

const Container = styled(ViewPager)`
  height: ${height+30}px;
    width: auto;
`
const Gradient = styled(LinearGradient)`
  height: 100%;
  justify-content: space-between;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1;
`
const Center = styled.View`
  flex: 1;
  flex-direction: row;
`
import videos from '../services/api'
import Constants from 'expo-constants';
const following=['hGlTOeW6OuUEsLNRzRwXE9Nl3Kq2',];
const Foll = ({ navigation,route}) => {
const [selected, setSelected] = useState(0);
const [User, setUser] = useState(0);
console.disableYellowBox = true;
const {state,setState}=useState("");
const {city,setCity}=useState("");
const {lang,setLang}=useState("");
const user = firebase.auth().currentUser;
if (user) {
db.collection('following')
                .where('uid', '==',user.uid)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        following.push(documentSnapshot.data().following);
                            });
                });

              db.collection('videos')
                .where('uid', 'in',following)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videos.push(documentSnapshot.data());
                            });
                });
                console.log(following);
                console.log(videos);
        }
        else{
        navigation.navigate("Home");
        }
  return (
    <Container
      orientation='vertical'
      onPageSelected={e => setSelected(e.nativeEvent.position)}
      initialPage={0}>
      {videos.map((item, index) => {
      let uxl=String(item.video);
      let uxx=String(item.poster);
      if (User==1) {
        return (
          <View key={index}>
            <VideoPlayer
              video={{ uri: uxl }}
              poster={{uri:uxx}}
              isPlay={selected === index}
            />
            <Gradient
              locations={[0, 0.26, 0.6, 1]}
              colors={[
                'rgba(26,26,26,0.6)',
                'rgba(26,26,26,0)',
                'rgba(26,26,26,0)',
                'rgba(26,26,26,0.6)'
              ]}>
              <Center>
                <Info username={item.username} dis={item.disc} music={item.song} uid={item.uid} navigation={navigation} vid={item.name}/>
                <Sidebar vid={item.name} download={item.video} navigation={navigation} uid={item.uid}/>
              </Center>
            </Gradient>
          </View>
        )
      }
      else{
        return(
        <Container>
        <ScrollView style={{backgroundColor: "#FFFFFF"}}>
                <View style={{ alignSelf: "center",justifyContent:"center",alignItems:"center",marginTop:270}}>
                    <View style={{width: "120%",
        height: "80%",justifyContent:"center",alignItems:"center"}}>
        <TouchableOpacity onPress={() => navigation.navigate("Loginx")}>
                        <Image style={{flex: 1,
                          height: 200,
                          width: 250,
                          justifyContent: 'center',
        alignItems: 'center',}} source={require('../images/login.png')}/>
        </TouchableOpacity>
                    </View>
                </View>
            </ScrollView>
            </Container>
        )
        
      }
      })}
    </Container>
  )
}

export default Foll
