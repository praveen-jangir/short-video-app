import React, { useState } from 'react'

import { Dimensions, View,TouchableOpacity } from 'react-native'

import { LinearGradient } from 'expo-linear-gradient'

import styled from 'styled-components/native'

import ViewPager from '@react-native-community/viewpager'

import VideoPlayer from '../components/VideoPlayer'
import Info from '../components/Info'
import Sidebar from '../components/Sidebar'

const { height } = Dimensions.get('window')

const Container = styled(ViewPager)`
  height: ${height+30}px;
    width: auto;
`
const Gradient = styled(LinearGradient)`
  height: 100%;
  justify-content: space-between;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1;
`
const Center = styled.View`
  flex: 1;
  flex-direction: row;
`
import Constants from 'expo-constants';
const Hero = ({ videos,navigation,route }) => {
  try{
     alert(route.mute)
   }
   catch{
    alert("error:")
   }
    const [selected, setSelected] = useState(0);

  return (
    <Container
      orientation='vertical'
      onPageSelected={e => setSelected(e.nativeEvent.position)}
      initialPage={0}>
      {videos.map((item, index) => {
      let uxl=String(item.video);
      let uxx=String(item.poster);
        return (
          <View key={index}>
            <VideoPlayer
              video={{ uri: uxl }}
              poster={{uri:uxx}}
              isPlay={selected === index}
            />
            <Gradient
              locations={[0, 0.26, 0.6, 1]}
              colors={[
                'rgba(26,26,26,0.6)',
                'rgba(26,26,26,0)',
                'rgba(26,26,26,0)',
                'rgba(26,26,26,0.6)'
              ]}>
              <Center>
                <Info username={item.username} dis={item.disc} music={item.song} uid={item.uid} navigation={navigation} vid={item.name}/>
                <Sidebar vid={item.name} download={item.video} navigation={navigation} uid={item.uid}/>
              </Center>
            </Gradient>
            
          </View>

        )
      })}
    </Container>
  )
}

export default Hero
