import React from 'react'

import { Video } from 'expo-av'
import { Dimensions, View,TouchableOpacity,Text } from 'react-native'

import styled from 'styled-components/native'

const Play = styled(Video)`
	height: 100%;
	background:black;
`
const Poster = styled.ImageBackground`
	height: auto;
	width:100%;
`

const VideoPlayer = ({ video, poster, isPlay }) => {

	return isPlay ? (
		<>
		<View>
		<Play
		style={{width:"auto",height:"100%"}}
			rate={1.0}
			volume={1.0}
			isMuted={false}
			shouldPlay
			useNativeControls={false}
			posterSource={poster}
			source={video}
			usePoster={true}
            isLooping={true}
			resizeMode='cover'
		/>
		</View>
		</>
	) : (
		<Play
			rate={1.0}
			volume={1.0}
			isMuted={true}
			useNativeControls={true}
			posterSource={poster}
			source={video}
			usePoster={true}
			resizeMode='cover'
		/>
	)
}

export default VideoPlayer
