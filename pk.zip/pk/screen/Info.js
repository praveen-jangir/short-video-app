import React, {Component} from 'react';  
import {ImageBackground,TouchableOpacity,StyleSheet, Text, View, SafeAreaView, Image, ScrollView,  FlatList,
  ActivityIndicator,} from 'react-native';  

type Props = {}; 
const videos =[{"name":"Hindi"},{"name":"English"}]
function Laguage() {
   return(
    <View>
                <View style={styles.MainContainer}>
        <FlatList
          data={videos}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:200 }}>
            <TouchableOpacity onPress={() => this.navigation.navigate("UserHome",{videos:videos})}>
              <Image style={styles.imageThumbnail} source={{ uri: item.poster }}/>
              <Text>{item.name}</Text>
              </TouchableOpacity>
            </View>
          )}
          //Setting the number of column
          numColumns={3}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
</View>
)
 } 
export default class Info extends Component<Props> {  
  render() {  
    return (<Laguage/>  
    );  
  }  
}  
  
const styles = StyleSheet.create({  
  container: {  
    flex: 1,  
    justifyContent: 'center',  
    alignItems: 'center',  
    backgroundColor: '#F5FCFF',  
  },  
  welcome: {  
    fontSize: 20,  
    textAlign: 'center',  
    margin: 10,  
  },  
  instructions: {  
    textAlign: 'center',  
    color: '#333333',  
    marginBottom: 5,  
  },
  MainContainer: {
    justifyContent: 'center',
    flex: 1,
    paddingTop: 30,
  },  
});  