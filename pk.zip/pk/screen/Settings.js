import React, {Component} from 'react';
import { ImageBackground,TouchableOpacity,StyleSheet, Text, View, SafeAreaView, Image, ScrollView,  FlatList,
  ActivityIndicator,Linking } from "react-native";
import Icon from 'react-native-vector-icons/FontAwesome';
import { Camera } from 'expo-camera';
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import styled from 'styled-components/native';
import Poster from './poster.js';
import firebase from './firebase.js';
import DatePicker from 'react-native-datepicker';
import { TextInput } from 'react-native-paper';
import 'firebase/firestore';
import * as ImagePicker from 'expo-image-picker';
const dbh = firebase.firestore();
export default class Settings extends Component<props> {
    state={
        LogOut:"yes"
    }
    constructor({ route, navigation }){
            const user = firebase.auth().currentUser;
      super();
      this.state={
        login:"no",
        navigation:navigation,
      }
        if (user>0) {
              this.setState({LogOut:"no"});
            }
    }

    LogOut =()=>{
        firebase.auth().signOut();
        this.state.navigation.goBack();
        this.state.navigation.goBack();
      }
    Account =()=>{
        this.state.navigation.goBack();
      }
render(){
    return (
      <View style={{flex:1,marginTop:0,backgroundColor:"white"}}>
      <View>
      <Text style={{fontSize:15,fontWeight:"bold",marginLeft:20,marginBottom:20,color:"#9e9e9e",marginTop:20}}>ACCOUNT</Text>
            <View>
            <TouchableOpacity onPress={this.Account}>
            <Text style={{fontSize:16,marginLeft:25,color:"Black",textAlignVertical: 'top'}}>
            <Icon name="user" style={{color:"#9e9e9e",fontSize:16}} />  My Account</Text>
            </TouchableOpacity>
            <View style={{borderWidth:1,padding:8,width:70,backgroundColor:"red",borderRadius:5,borderColor:"white",flexDirection:"row-reverse",alignItems:"flex-end",marginRight:250,marginTop:-25}}>
            {this.state.login == "no"?
            <TouchableOpacity onPress={this.LogOut}>
            <Text style={{color:"white"}}>LogOut</Text>
            </TouchableOpacity>:<TouchableOpacity>
            <Text style={{color:"white"}}>LogIn  </Text>
            </TouchableOpacity>}
            </View>
            </View>
            <View style={{marginTop:20,borderBottomWidth:0.3,borderColor:"#9e9e9e"}}>
            <TouchableOpacity>
            <Text style={{fontSize:16,marginLeft:25,color:"Black",marginBottom:20}}>
            <Icon name="camera" style={{color:"#9e9e9e",fontSize:16}} />  Content Preferences</Text>
            </TouchableOpacity>
            </View>
            </View>


              <View>
      <Text style={{fontSize:15,fontWeight:"bold",marginLeft:20,marginBottom:20,color:"#9e9e9e",marginTop:20}}>GENERAL</Text>
            <View>
            <TouchableOpacity>
            <Text style={{fontSize:16,marginLeft:25,color:"Black",textAlignVertical: 'top'}}>
            <Icon name="language" style={{color:"#9e9e9e",fontSize:16}} />  Language</Text>
            </TouchableOpacity>
            </View>
            <View style={{marginTop:20,borderBottomWidth:0.3,borderColor:"#9e9e9e"}}>
            <TouchableOpacity>
            <Text style={{fontSize:16,marginLeft:25,color:"Black",marginBottom:20}}>
            <Icon name="tint" style={{color:"#9e9e9e",fontSize:16}} />  Data Saver</Text>
            </TouchableOpacity>
            </View>
            </View>



            <View>
            <Text style={{fontSize:15,fontWeight:"bold",marginLeft:20,marginBottom:20,color:"#9e9e9e",marginTop:20}}>SUPPORT</Text>
            <View>
            <TouchableOpacity onPress={ ()=> Linking.openURL('https://edugyangroup.com') }>
            <Text style={{fontSize:16,marginLeft:25,color:"Black",textAlignVertical: 'top'}}>
            <Icon name="question-circle" style={{color:"#9e9e9e",fontSize:16}} />  Help Center</Text>
            </TouchableOpacity>
            </View>
            <View style={{marginTop:20,borderBottomWidth:0.3,borderColor:"#9e9e9e"}}>
            <TouchableOpacity onPress={ ()=> Linking.openURL('https://edugyangroup.com') }>
            <Text style={{fontSize:16,marginLeft:25,color:"Black",marginBottom:20}}>
            <Icon name="user-secret" style={{color:"#9e9e9e",fontSize:16}} />  Safety Center</Text>
            </TouchableOpacity>
            </View>
            </View>


              <View>
            <Text style={{fontSize:15,fontWeight:"bold",marginLeft:20,marginBottom:20,color:"#9e9e9e",marginTop:20}}>ABOUT</Text>
            <View>
            <TouchableOpacity onPress={ ()=> Linking.openURL('https://edugyangroup.com') }>
            <Text style={{fontSize:16,marginLeft:25,color:"Black",textAlignVertical: 'top'}}>
            <Icon name="database" style={{color:"#9e9e9e",fontSize:16}} />  Terms of Use</Text>
            </TouchableOpacity>
            </View>
            <View style={{marginTop:20,borderBottomWidth:0.3,borderColor:"#9e9e9e"}}>
            <TouchableOpacity onPress={ ()=> Linking.openURL('https://edugyangroup.com') }>
            <Text style={{fontSize:16,marginLeft:25,color:"Black",marginBottom:20}}>
            <Icon name="fax" style={{color:"#9e9e9e",fontSize:16}} />  Community Guidelines</Text>
            </TouchableOpacity>
            </View>
            </View>
            <View>
<Text style={{fontSize:16,color:"Black",marginBottom:0,textAlign:"center",marginTop:10}}>Version 1.5.1</Text>
            </View>

      </View>
    );
    }
}

const Separator = styled.View`
    width: 1px;
    height: 13px;
    background-color: #d8d8d8;
    opacity: 0.6;
`
const Button = styled.View`
    width: 130px;
    height: 36px;
    justify-content: center;
    align-items: center;
    margin-left:100px;
    margin-top:12px
`
const Menu = styled.View`
    margin-top:-38px;
    margin-left:150px;
    align-items: center;
`
const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop:0,
        backgroundColor: "#FFF"
    },
    text: {
        color: "#52575D"
    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
        borderRadius:80
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 12,
        color: "#AEB5BC",
        textTransform: "uppercase",
        fontWeight: "500"
    },
    profileImage: {
        width: 120,
        height: 120,
        borderRadius: 80,
        overflow: "hidden"
    },
    add: {
        backgroundColor: "#41444B",
        position: "absolute",
        top:100,
        left: 40,
        width: 35,
        height: 35,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        alignSelf: "center",
        alignItems: "center",
        marginTop: 0
    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: 12
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 343,
        height: 650,
        borderRadius: 12,
        overflow: "hidden",
        marginTop:10,
        marginHorizontal: 10
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },

    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    gridView: {
    marginTop: 20,
    flex: 1,
  },
  itemContainer: {
    justifyContent: 'flex-end',
    borderRadius: 5,
    padding: 10,
    height: 150,
  },
  itemName: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
  },
  itemCode: {
    fontWeight: '600',
    fontSize: 12,
    color: '#fff',
  },
  sectionHeader: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
    alignItems: 'center',
    backgroundColor: '#636e72',
    color: 'white',
    padding: 10,
  },
  MainContainer: {
    justifyContent: 'center',
    flex: 1,
    paddingTop: 30,
  },
  imageThumbnail: {
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
    width:'100%',
  },
});