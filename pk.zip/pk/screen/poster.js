import React, { Component } from 'react';
//import rect in our project
import {
  StyleSheet,
  View,
  FlatList,
  ActivityIndicator,
  Image,
  TouchableOpacity,
} from 'react-native';
//import all the components we will need
import { withNavigation } from 'react-navigation';

export default class Poster extends Component<props> {
  constructor(props) {
    super(props);
    const Uid=this.props.uid;
    this.props.navigation.navigate("Camera");
    this.state = {
      dataSource: [],
      uid:Uid
    };
  }
  fetchData= async()=>{
    const pid=this.state.uid;
    const response = await fetch('https://mandawamart.com/admin/videos.php?pid=1');
    const users = await response.json();
    this.setState({dataSource: users});
  }
componentDidMount(){
  this.fetchData();
}

  render(){
    return (
      <View style={styles.MainContainer}>
        <FlatList
          data={this.state.dataSource}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:200 }}>
            <TouchableOpacity>
              <Image style={styles.imageThumbnail} source={{ uri: item.poster }}/>
              </TouchableOpacity>
            </View>
          )}
          //Setting the number of column
          numColumns={3}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  MainContainer: {
    justifyContent: 'center',
    flex: 1,
    paddingTop: 30,
  },
  imageThumbnail: {
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
    width:'100%',
  },
});