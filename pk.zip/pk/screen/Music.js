import React, {Component} from 'react';
import { ImageBackground,TouchableOpacity,StyleSheet, Text, View, SafeAreaView, Image, ScrollView,  FlatList,
  ActivityIndicator, } from "react-native";
import { Ionicons, MaterialIcons } from "@expo/vector-icons";
import styled from 'styled-components/native';
import Poster from './poster.js';
import firebase from './firebase.js';
const dbh = firebase.firestore();
const goToFav = () => {
      alert("Favrate");
      }
      const goToGrid = () => {
      alert("Grid view");
      }
      const goToLove = () => {
      alert("Loved videos");
      }
const videos=[];
export default class Music extends Component<props> {
    constructor(props){
      const {Music} = props.route.params;
      super(props);
      this.state = {
          TextHolder:'Follow',
          Color:'#ff0090',
          bg:'white',
          Uid:"uid",
          userName:'',
          FolloWer:'',
          music:Music,
          FolloWing:'',
          Post:'',
          Avtar:'../assets/profile-pic.jpg',
          dataSource:'',
      }
        const user = firebase.auth().currentUser;
        if (user) {
           dbh.collection('videos')
           .where('name', '==',this.state.music)
            .get()
            .then(querySnapshot => {
              querySnapshot.forEach(documentSnapshot => {
                var i=0;
                   while(videos.length>=i){
                     delete videos[i];
                     i++;
                   }
                    videos.push(documentSnapshot.data());
              });
            });
         const data = dbh.collection("user").doc(user.uid).get().then(documentSnapshot => {
         this.setState({userName:documentSnapshot.data().username})
         });
    }
  }

render(){
    return (
        <SafeAreaView style={styles.container}>
            <ScrollView>
                <View style={{ marginLeft:20,marginTop:20 }}>
                    <View style={styles.profileImage}>
                        <Image source={require('../assets/avatar/01.jpg')} style={styles.image}></Image>
                    </View>
                </View>
                <View style={styles.infoContainer}>
                    <Text style={[styles.text, { fontWeight: "200", fontSize: 17 }]}>Orignal_sound</Text>
                    <Text style={[styles.text, { color: "#AEB5BC", fontSize: 14 }]}>@ its_praveen_jd</Text>
                    <Text style={[styles.text, { color: "#AEB5BC", fontSize: 14,marginLeft:-70 }]}>16.5K</Text>
                </View>
                <View>
                <TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5}>
          {/*We can use any component which is used to shows something inside 
             TouchableOpacity. It shows the item inside in horizontal orientation */}
          <Image
            //We are showing the Image from online
            source={{
              uri:
                'https://cdn.clipart.email/51d663379c2127f9240f6b677bce03a2_flag-instagram-interface-save-tag-icon_512-512.png',
            }}
            //You can also show the image from you project directory like below
            //source={require('./Images/facebook.png')}
            //Image Style
            style={styles.ImageIconStyle}
          />
          <View style={styles.SeparatorLine} />
          <Text style={styles.TextStyle}> Add to Favorites </Text>
        </TouchableOpacity>
                </View>
<View>
                <View style={styles.MainContainer}>
        <FlatList
          data={videos}
          renderItem={({ item }) => (
            <View style={{ flex: 1, flexDirection: 'column', margin: 1,height:200 }}>
            <TouchableOpacity onPress={() => this.props.navigation.navigate("UserHome",{videos:videos})}>
              <Image style={styles.imageThumbnail} source={{ uri: item.poster }}/>
              </TouchableOpacity>
            </View>
          )}
          //Setting the number of column
          numColumns={3}
          keyExtractor={(item, index) => index.toString()}
        />
      </View>
</View>
            </ScrollView>
        </SafeAreaView>
    );
    }
}

const Separator = styled.View`
    width: 1px;
    height: 13px;
    background-color: #d8d8d8;
    opacity: 0.6;
`
const Button = styled.View`
    width: 130px;
    height: 36px;
    justify-content: center;
    align-items: center;
    margin-left:100px;
    margin-top:12px
`
const Menu = styled.View`
    margin-top:-38px;
    margin-left:150px;
    align-items: center;
`
const Icon = styled.Image`
    height: 40px;
`
const styles = StyleSheet.create({
    container: {
        flex: 1,
        marginTop:1,
        backgroundColor: "#FFF"
    },
    text: {
        color: "#52575D"
    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined
    },
    titleBar: {
        flexDirection: "row",
        justifyContent: "space-between",
        marginTop: 24,
        marginHorizontal: 16
    },
    subText: {
        fontSize: 12,
        color: "#AEB5BC",
        textTransform: "uppercase",
        fontWeight: "500"
    },
    profileImage: {
        width: 100,
        height: 100,
        overflow: "hidden"
    },
    add: {
        backgroundColor: "#41444B",
        position: "absolute",
        top:100,
        left: 40,
        width: 35,
        height: 35,
        borderRadius: 20,
        alignItems: "center",
        justifyContent: "center"
    },
    infoContainer: {
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'space-between',
        justifyContent: "flex-end",
        alignItems: 'center',
        marginLeft:25,
        marginTop:-100

    },
    statsContainer: {
        flexDirection: "row",
        alignSelf: "center",
        marginTop: 12
    },
    statsBox: {
        alignItems: "center",
        flex: 1
    },
    mediaImageContainer: {
        width: 343,
        height: 650,
        borderRadius: 12,
        overflow: "hidden",
        marginTop:10,
        marginHorizontal: 10
    },
    mediaCount: {
        backgroundColor: "#41444B",
        position: "absolute",
        top: "50%",
        marginTop: -50,
        marginLeft: 30,
        width: 100,
        height: 100,
        alignItems: "center",
        justifyContent: "center",
        borderRadius: 12,
        shadowColor: "rgba(0, 0, 0, 0.38)",
        shadowOffset: { width: 0, height: 10 },
        shadowRadius: 20,
        shadowOpacity: 1
    },
    recent: {
        marginLeft: 78,
        marginTop: 32,
        marginBottom: 6,
        fontSize: 10
    },
    recentItem: {
        flexDirection: "row",
        alignItems: "flex-start",
        marginBottom: 16
    },

    activityIndicator: {
        backgroundColor: "#CABFAB",
        padding: 4,
        height: 12,
        width: 12,
        borderRadius: 6,
        marginTop: 3,
        marginRight: 20
    },
    gridView: {
    marginTop: 20,
    flex: 1,
  },
  itemContainer: {
    justifyContent: 'flex-end',
    borderRadius: 5,
    padding: 10,
    height: 150,
  },
  itemName: {
    fontSize: 16,
    color: '#fff',
    fontWeight: '600',
  },
  itemCode: {
    fontWeight: '600',
    fontSize: 12,
    color: '#fff',
  },
  sectionHeader: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
    alignItems: 'center',
    backgroundColor: '#636e72',
    color: 'white',
    padding: 10,
  },
  MainContainer: {
    justifyContent: 'center',
    flex: 1,
    paddingTop: 30,
  },
  imageThumbnail: {
    justifyContent: 'center',
    alignItems: 'center',
    height: '100%',
    width:'100%',
  },
  FacebookStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderWidth: 0.5,
    borderColor: '#ccc',
    height: 30,
    width: 150,
    borderRadius: 5,
    margin: 5,
    marginTop:10,
    marginLeft:140
  },
  ImageIconStyle: {
    padding: 10,
    margin: 5,
    height: 25,
    width: 25,
    resizeMode: 'stretch',
  },
  TextStyle: {
    color: '#000',
    marginBottom: 4,
    marginRight: 20,
  },
  SeparatorLine: {
    backgroundColor: '#ccc',
    width: 1,
    height: 30,
  },
});