import React from 'react';
import {
  SafeAreaView,
  StyleSheet,
  ScrollView,
  View,
  Text,
  StatusBar,
} from 'react-native';
import Profile from './Profile.js'
import Home from './Home.js'
import {
  Header,
  LearnMoreLinks,
  Colors,
  DebugInstructions,
  ReloadInstructions,
} from 'react-native/Libraries/NewAppScreen';
import Icon from 'react-native-vector-icons/Ionicons';
import {createAppContainer} from 'react-navigation';
import styled from 'styled-components/native'
import { LinearGradient } from 'expo-linear-gradient'

import { Feather } from '@expo/vector-icons'
import {createMaterialBottomTabNavigator} from 'react-navigation-material-bottom-tabs';
const Menu = styled.TouchableOpacity`
  width: 20%;
  height: 100%;
  justify-content: center;
  align-items: center;
`

const MenuText = styled.Text`
  font-size: 9px;
  margin-top: -3px;
  color: ${props => (props.active ? '#fff' : 'rgba(255,255,255,0.6)')};
`
const Border = styled(LinearGradient)`
  width: 44px;
  height: 28px;
  border-radius: 8px;
  align-items: center;
`
const Button = styled.View`
  width: 36px;
  height: 28px;
  background: #fff;
  border-radius: 8px;
  justify-content: center;
  align-items: center;
`
class HomeScreen extends React.Component {
  render() {
    return (
      <Home/>
    )
  }
}

class ProfileScreen extends React.Component {
  render() {
    return (
      <Profile/>
    )
  }
}
class PlusScreen extends React.Component {
  render() {
    return (
      <Profile/>
    )
  }
}
class HistoryScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Text>HistoryScreen</Text>
      </View>
    )
  }
}

class CartScreen extends React.Component {
  render() {
    return (
      <View style={styles.container}>
        <Text>CartScreen</Text>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 2,
    justifyContent: 'center',
    alignItems: 'center',
    borderTopWidth:0,
  }
});

const TabNavigator = createMaterialBottomTabNavigator(
  {
    Home: {
      screen: HomeScreen,
      navigationOptions: {
        tabBarIcon: ({ tintColor }) => (
          <View>
            <Icon style={[{color: tintColor}]} size={28} name={'ios-home'} />
          </View>
        ),
      }
    },
    History: {
      screen: HistoryScreen,
      navigationOptions: {
        tabBarIcon: ({ tintColor }) => (
          <View>
            <Icon style={[{color: tintColor}]} size={27} name={'ios-search'} />
          </View>
        ),
        activeColor: '#000000',
        inactiveColor: '#696969',
        barStyle: { backgroundColor: '#ffffff' },
      }
    },
Plus: {
      screen: PlusScreen,
      navigationOptions: {
        tabBarIcon: ({ tintColor }) => (
          <Menu>
        <Border
          start={{ x: 1, y: 0 }}
          locations={[0, 0.5, 0.5, 1]}
          colors={['#F42365', '#f42365', '#37d7cf', '#37d7cf']}>
          <Button>
            <Feather name='plus' size={24} />
          </Button>
        </Border>
      </Menu>
        ),
        activeColor: '#000000',
        inactiveColor: '#696969',
        barStyle: { backgroundColor: '#ffffff' },
      }
    },
    Cart: {
      screen: CartScreen,
      navigationOptions: {
        tabBarIcon: ({ tintColor }) => (
          <View>
            <Icon style={[{color: tintColor}]} size={27} name={'ios-book'} />
          </View>
        ),
        activeColor: '#000000',
        inactiveColor: '#696969',
        barStyle: { backgroundColor: '#ffffff' },
      }
    },
    Profile: {
      screen: ProfileScreen,
      navigationOptions: {
        tabBarIcon: ({ tintColor }) => (
          <View>
            <Icon style={[{color: tintColor}]} size={27} name={'ios-person'} />
          </View>
        ),
        activeColor: '#000000',
        inactiveColor: '#696969',
        barStyle: { backgroundColor: '#ffffff' },
      }
    },
  },
  {
    initialRouteName: 'Home',
    activeColor: '#ffffff',
    inactiveColor: '#DCDCDC',
    barStyle: { backgroundColor: 'transparent',marginBottom:10 },
  }
);

export default createAppContainer(TabNavigator);