import React, { useState,Component } from 'react'
import { Video } from 'expo-av'
import { StyleSheet, Text, View ,TouchableOpacity,Platform,Buttton } from 'react-native';
import styled from 'styled-components/native'
import firebase from './firebase';

const Play = styled(Video)`
  height: 100%;
`
const Poster = styled.ImageBackground`
  height: 100%;
`
const Iconbb = styled.Image`
  height: 100px;
  width: 100px;
  position: absolute;
`
const Containerb = styled.View`
  height: 60px;
  width: 100%;
  position: absolute;
  bottom: 35px;
  z-index: 1;
  justify-content: center;
  border-top-width: 0px;
  border-top-color: rgba(255, 255, 255, 0.2);
  flex-direction: row;
`
const Menub = styled.TouchableOpacity`
  width: 72%;
  height: 100%;
  justify-content: center;
  align-items: center;
`
const Iconb = styled.Image.attrs({ resizeMode: 'contain' })`
  height: 35px;
  width: 50px;
`
const MenuTextb = styled.Text`
  font-size: 12px;
  margin-top: 5px;
  color: ${props => (props.active ? '#fff' : 'rgba(255,255,255,0.6)')};
`
export default class VideoPlayer extends Component<props> {
  constructor(props) {
    const {VideoE} = props.route.params;
    super(props);
    this.state=({
      videox:VideoE,
      loading:"not",
      mute:false,
    })
}
render(){
  const Disc =()=>{
    this.setState({mute:true});
    this.props.navigation.navigate("Disc",{videos:this.state.videox});
  }
  return (
  <View style={{backgroundColor: '#000000',
    width: '100%',
    height: '100%',
    position: 'relative',
    justifyContent: 'center',
    alignItems: 'center'}}>
    <Video
    source={{ uri: this.state.videox }}
    rate={1.0}
    volume={1.0}
    isMuted={this.state.mute}
    resizeMode="cover"
    shouldPlay
    isLooping
  style={{height:'100%',width:'100%'}}
/>
{this.state.loading == "yes" ?<Iconbb source={require('../images/loading.gif')} />:null}
      <Containerb>
      <Menub>
        <Iconb source={require('../images/editing.png')} />
        <MenuTextb active='true'>Edit</MenuTextb>
      </Menub>
      <Menub>
      <TouchableOpacity onPress={Disc}>
        <Iconb source={require('../images/uploads.png')} />
        </TouchableOpacity>
        <MenuTextb active='true'>Upload</MenuTextb>
      </Menub>
    </Containerb>
</View>
  );
}
}