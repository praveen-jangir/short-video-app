import React, { useState, useEffect } from 'react';
import { LinearGradient } from 'expo-linear-gradient'
import { Camera } from 'expo-camera';
import { AUDIO_RECORDING,Audio,Sound} from 'expo-av'
import * as Permissions from 'expo-permissions';
import * as ImagePicker from 'expo-image-picker';
import { Feather } from '@expo/vector-icons'
import { Text, View, TouchableOpacity,StyleSheet,Image } from 'react-native';
import styled from 'styled-components/native'
const Container = styled.View`
  width: 60px;
  height: 100%;
  padding-bottom: 59px;
  right:-295px;
  top:-250px;
  justify-content: flex-end;
`
const Menu = styled.View`
  margin: 9px 0;
  align-items: center;
`
const User = styled.View`
  width: 48px;
  height: 48px;
  margin-bottom: 13px;
`
const Avatar = styled.Image`
  width: 100%;
  height: 100%;
  border-radius: 48px;
  border-width: 2px;
  border-color: #ffffff;
`
const Icon = styled.Image`
  height: 35px;
`
const Count = styled.Text`
  color: #fff;
  font-size: 12px;
  letter-spacing: -0.1px;
`
const SoundBg = styled.View`
  background: #1f191f;
  width: 50px;
  height: 50px;
  border-radius: 50px;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
`
const Containerb = styled.View`
  height: 60px;
  width: 100%;
  position: absolute;
  bottom: 85px;
  z-index: 1;
  justify-content: center;
  border-top-width: 0px;
  border-top-color: rgba(255, 255, 255, 0.2);
  flex-direction: row;
`
const Containerbb = styled.View`
  height: 60px;
  width: 100%;
  position: absolute;
  top: 30px;
  z-index: 1;
  justify-content: flex-start;
  border-top-width: 0px;
  border-top-color: rgba(255, 255, 255, 0.2);
  flex-direction: row;
`

const Menub = styled.TouchableOpacity`
  width: 35%;
  height: 100%;
  justify-content: center;
  align-items: center;
`
const Menubb = styled.TouchableOpacity`

  width: 40%;
  height: 100%;
  margin-top:-6px;
  justify-content: flex-end;
  align-items: center;
`
const Menubbb = styled.TouchableOpacity`
  width: 40%;
  margin-left:-30px;
  height: 100%;
  justify-content: flex-end;
  align-items: center;
`
const Iconb = styled.Image.attrs({ resizeMode: 'contain' })`
  height: 35px;
  width: 50px;
`
const Iconbb = styled.Image.attrs({ resizeMode: 'contain' })`
  height: 60px;
  width: 60px;
  border-radius:100px;
`
const MenuTextb = styled.Text`
  font-size: 12px;
  margin-top: 5px;
  color: ${props => (props.active ? '#fff' : 'rgba(255,255,255,0.6)')};
`
const MenuTextbb = styled.Text`
  font-size: 16px;
  margin-top: 0px;
  justify-content: center;
  align-items: center;
  color: ${props => (props.active ? '#fff' : 'rgba(255,255,255,0.6)')};
`
const Border = styled(LinearGradient)`
  width: 44px;
  height: 28px;
  border-radius: 8px;
  align-items: center;
`
const Button = styled.View`
  width: 36px;
  height: 28px;
  background: #fff;
  border-radius: 8px;
  justify-content: center;
  align-items: center;
`

export default class Camerax extends React.Component<props> {
  state = {
    hasPermission: null,
    videos : null,
    now:true,
    data:null,
    cameraType: Camera.Constants.Type.back,
    music:"",
    timer:60,
    start:"play",
    min: 0,
    sec: 0,
    msec: 0,
  }
  constructor({route,navigation}) {
    navigation.setOptions({ tabBarVisible: false })
    super();
try {
    const {Music} =route.params;
    const {Name} =route.params;
    this.music={
      Sound:Music,
      Name:Name,
    } 
}catch (error) {
    const Music ="";
      this.music={
      Sound:Music,
    } 
}
}

  async componentDidMount() {
    this.getPermissionAsync()
    this.getPermissionAsync()
  }
  getPermissionAsync = async () => {
    // Camera roll Permission 
    if (Platform.OS === 'android') {
      const { status } = await Permissions.askAsync(Permissions.CAMERA_ROLL);
      if (status !== 'granted') {
        alert('Sorry, we need camera roll permissions to make this work!');
      }
    }
    // Camera Permission
    const { status } = await Permissions.askAsync(Permissions.CAMERA,Permissions.AUDIO_RECORDING
);
    this.setState({ hasPermission: status === 'granted' });
  }

  handleCameraType=()=>{
    const { cameraType } = this.state

    this.setState({cameraType:
      cameraType === Camera.Constants.Type.back
      ? Camera.Constants.Type.front
      : Camera.Constants.Type.back
    })
  }

  takePicture = async () => {
    this.setState({start:"stop"})
    if (this.camera) {
      try{
      const soundObject = new Audio.Sound();
      const source = { uri: this.music.Sound };
        await soundObject.loadAsync(source);
        await soundObject.playAsync();
      }
      catch{

      }
      const options = {quality:'720p',maxDuration:3};
      let photo = await this.camera.recordAsync(options);
      this.setState({start:"play"})
      console.log(photo);
      if (!photo.cancelled) {
        await soundObject.unloadAsync();
       /* alert(photo.uri);*/
       this.props.navigation.navigate('VideoPlayer',{VideoE: photo.uri }  );
      }
    }
  }
  pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Videos
    });
    if (!result.cancelled) {
       /* alert(photo.uri);*/
       this.props.navigation.navigate('VideoPlayer',{VideoE: result.uri,navigation:this.props.navigation}  );
      }

  }
  back =() => {
   this.props.navigation.goBack();
  }
  render(){
    let padToTwo = (number) => (number <= 9 ? `0${number}`: number);
    const { navigation } = this.props;
    const { hasPermission } = this.state
    if (hasPermission === null) {
      return <View />;
    } else if (hasPermission === false) {
      return <Text>No access to camera</Text>;
    } else {
      return (
  <View style={{ flex: 1 }} >
      <Camera style={{ flex: 1, }} type={this.state.cameraType}  ref={ref => {this.camera = ref}}>
        <View
          style={{
            flex: 1,
            backgroundColor: 'transparent',
            flexDirection: 'row',
          }}>

          <Containerbb>
      <Menubbb>
      <TouchableOpacity onPress={this.back}>
        <Iconb source={require('../images/close.png')} />
        </TouchableOpacity>
      </Menubbb>
      <Menubb>
      {this.music.Sound == ""? <TouchableOpacity onPress={() => navigation.navigate('Soundx')}>
      <MenuTextbb active='true'>Select Sound</MenuTextbb>
      </TouchableOpacity>: <TouchableOpacity onPress={() => navigation.navigate('Soundx')}>
      <MenuTextbb active='true'>{this.music.Name.slice(0, 15)+"..."}</MenuTextbb>
      </TouchableOpacity>}
      </Menubb>
    </Containerbb>

    <Container style={{backgroundColor: 'transparent'}}>
      <Menu>
      <TouchableOpacity
             onPress={()=>this.handleCameraType()}>
        <Icon resizeMode='contain' source={require('../images/flip.png')} />
        </TouchableOpacity>
        <Count>Flip</Count>
      </Menu>
      <Menu>
      <TouchableOpacity>
        <Icon
          resizeMode='contain'
          source={require('../images/speed.png')}
        />
        </TouchableOpacity>
        <Count>Speed</Count>
      </Menu>

      <Menu>
        <Icon resizeMode='contain' source={require('../images/magic.png')} />
        <Count>Beauty</Count>
      </Menu>

      <Menu>
        <Icon resizeMode='contain' source={require('../images/filter.png')} />
        <Count>Filter</Count>
      </Menu>

      <Menu>
        <Icon resizeMode='contain' source={require('../images/timer.png')} />
        <Count>Timer</Count>
      </Menu>
    </Container>
    <Containerb>
      <Menub>
        <Iconb source={require('../images/effects.gif')} />
        <MenuTextb active='true'>Effects</MenuTextb>
      </Menub>

      <Menub>
      { this.state.start =='play' ?<TouchableOpacity onPress={()=>this.takePicture()}>
      <Iconbb source={require('../images/record.png')} />
      </TouchableOpacity>:<TouchableOpacity onPress={()=>this.camera.stopRecording()}>
      <Iconbb source={require('../images/play.gif')} />
      </TouchableOpacity>}
      </Menub>
      <Menub>
      <TouchableOpacity onPress={()=>this.pickImage()}>
        <Iconb source={require('../images/upload.jpg')} />
        </TouchableOpacity>
        <MenuTextb active='true'>Upload</MenuTextb>
      </Menub>
    </Containerb>
    </View>
      </Camera>
    </View>
  );
}
}
}

