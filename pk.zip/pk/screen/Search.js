/*import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View,FlatList} from 'react-native';
export default class App extends Component<Props> {

  state ={
    data:[]
  }

  fetchData= async()=>{
    const response = await fetch('https://raw.githubusercontent.com/Hardeepcoder/fake_json/master/Users');
    const users = await response.json();
    this.setState({data: users});

  }
componentDidMount(){
  this.fetchData();
}
  render() {
    return (
      <View >
       <Text>Welcome</Text>
       <FlatList
       data={this.state.data}
       keyExtractor={(item,index) => index.toString()}
       renderItem={({item}) =>

       <View style={{backgroundColor:'#abc123',padding:10,margin:10}}>
          <Text style={{color:'#fff', fontWeight:'bold'}}>{item.name}</Text>
          <Text style={{color:'#fff'}}>{item.email}</Text>
          <Text>City: {item.address.city}</Text>
         </View>

       }

       />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F5FCFF',
  },
});*/
import React, {Component} from 'react';
import { TouchableOpacity,StyleSheet, Text, View, SafeAreaView, Image, ScrollView } from "react-native";
import {
  Container,
  Header,
  Content,
  Left,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Item,
  Input
} from 'native-base';
  import firebase from './firebase.js';

const db = firebase.firestore();

let userx = require('../api/userList.json');
export default class Search extends Component {
  constructor({route,navigation}){
          const user = firebase.auth().currentUser;
     if (user) {
    db.collection('user')
    .where('uid','!=',user.uid)
  .get()
  .then(querySnapshot => {
    querySnapshot.forEach(documentSnapshot => {
          userx.push(documentSnapshot.data());
    });
  });
}
else{
  db.collection('user')
  .get()
  .then(querySnapshot => {
    querySnapshot.forEach(documentSnapshot => {
          userx.push(documentSnapshot.data());
    });
  });
}

    super();
    this.state = {
      allUsers: userx,
      usersFiltered: userx,
    };
  }
  componentDidMount() {}
  searchUser = text => {
    this.setState({
      usersFiltered: this.state.allUsers.filter(i =>
        i.username.toLowerCase().includes(text.toLowerCase()),
      )});
  };
  render() {
  const goToAbout = () => {
      return(
       <Routes/>
	  )
	  }
    return (
      <Container>
        <Header style={{backgroundColor:'#FFFFFF',marginTop:35}} searchBar rounded>
          <Item>
            
            <Input
              placeholder="Search"
              onChangeText={text => this.searchUser(text)}
            />
            <Icon name="ios-search"/>
          </Item>
        </Header>
        <Content>
          {this.state.usersFiltered.map(item => (
          
            <ListItem avatar>
            <TouchableOpacity onPress={() => this.props.navigation.navigate('Profile',{uid:item.uid})}>
              <Left>
                <Thumbnail source={require("../assets/avatar/02.jpg")} />
              </Left>
             </TouchableOpacity>
              <TouchableOpacity onPress={() => this.props.navigation.navigate("Profile",{uid:item.uid})}>
              <Body>
                <Text style={{ marginTop: 15 ,marginLeft: 10,fontSize:16,width:220 }}>{item.name}</Text>
                <Text  style={{ marginTop: 5 ,marginLeft: 10,fontSize:14,width:220 }}>@{item.username}</Text>
              </Body>
             </TouchableOpacity>
            </ListItem>
          
          ))}
        </Content>
      </Container>
    );
  }
}
const styles = StyleSheet.create({

    Header:{
        backgroundColor: "#FFFFFF",
        marginTop:"200px"
    }
});