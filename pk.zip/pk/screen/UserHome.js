
import { StyleSheet,TouchableOpacity,Text,StatusBar,Dimensions, View,Share,YellowBox,ScrollView,
  RefreshControl, } from 'react-native'

import styled from 'styled-components/native'
import _ from 'lodash';

import Header from '../components/Header'
import Hero from '../components/Hero'
import React, { Component,useState } from 'react'
import publicIP from 'react-native-public-ip';
import { LinearGradient } from 'expo-linear-gradient'
import { MaterialCommunityIcons } from '@expo/vector-icons';
import ViewPager from '@react-native-community/viewpager'

import VideoPlayer from '../components/VideoPlayer'
import Info from '../components/Info'
import firebase from './firebase.js';
const Container = styled.View`
  flex: 1;
  background: transparent;
`
const { height } = Dimensions.get('window')

const Containerh = styled(ViewPager)`
  height: ${height}px;
`
const Gradient = styled(LinearGradient)`
  height: 100%;
  justify-content: space-between;
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  z-index: 1;
`
const Center = styled.View`
  flex: 1;
  flex-direction: row;
`
const Containerb = styled.View`
  width: 60px;
  height: 100%;
  padding-bottom: 59px;
  justify-content: flex-end;
`
const Menu = styled.View`
  margin: 9px 0;
  align-items: center;
`
const User = styled.View`
  width: 48px;
  height: 48px;
  margin-bottom: 13px;
`
const Avatar = styled.Image`
  width: 100%;
  height: 100%;
  border-radius: 48px;
  border-width: 2px;
  border-color: #ffffff;
`
const Icon = styled.Image`
  height: 40px;
`
const Count = styled.Text`
  color: #fff;
  font-size: 12px;
  letter-spacing: -0.1px;
`
const SoundBg = styled.View`
  background: #1f191f;
  width: 50px;
  height: 50px;
  border-radius: 50px;
  justify-content: center;
  align-items: center;
  margin-top: 20px;
`
const Sound = styled.Image`
  width: 25px;
  height: 25px;
  border-radius: 25px;
`
const db = firebase.firestore();
import videos from '../services/api'
const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    backgroundColor: '#DDDDDD',
    padding: 10,
    width: 300,
    marginTop: 16,
  },
});
const wait = (timeout) => {
  return new Promise(resolve => {
    setTimeout(resolve, timeout);
  });
}
const UserHome = ({navigation}) => {

 const [refreshing, setRefreshing] = React.useState(false);

  const onRefresh = React.useCallback(() => {
    setRefreshing(true);
    wait(2000).then(() => setRefreshing(false));
  }, []);
console.disableYellowBox = true;
const {state,setState}=useState("");
const {city,setCity}=useState("");
const {lang,setLang}=useState("");
  publicIP()
          .then(ip => {
                  var url = 'http://api.ipstack.com/'+ip+'?access_key=7d2446dd2b89b6bbbe347e21777e6cb5';
          fetch(url)
            .then((response) => response.json())
            .then((responseJson) => {
              db.collection('videos')
                .where('state', '==',responseJson.region_code)
                .where('lang', '==',responseJson.location.languages[0].code)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videos.push(documentSnapshot.data());
                            });
                });
            })
            .catch((error) => {
              alert(responseJson.city);
             //console.error(error);
            });
          })
          .catch(error => {
            alert(responseJson.city);
            console.log(error);
            // 'Unable to get IP address.'
          });
  return (
    <>
      <StatusBar
        translucent
        backgroundColor='transparent'
        barStyle='light-content'
      />
      <Container
       refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <Header/>
        <Hero videos={videos} navigation={navigation}/>
      </Container>
    </>
  )
}

export default UserHome;
