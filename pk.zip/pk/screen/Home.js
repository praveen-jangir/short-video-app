
import { StyleSheet,Text,StatusBar,Dimensions, View,} from 'react-native'

import styled from 'styled-components/native'
import Header from '../components/Header'
import Hero from '../components/Hero'
import Foll from '../components/Foll'
import React from 'react'
import publicIP from 'react-native-public-ip';
import firebase from './firebase.js';
import ViewPager from '@react-native-community/viewpager'
import { useRoute } from '@react-navigation/native';

const { height } = Dimensions.get('window')

const Container = styled(ViewPager)`
  height: ${height+30}px;
  width: auto;
  flex: 1;
  background: transparent;
`
const db = firebase.firestore();
import videos from '../services/api'
const styles = StyleSheet.create({
  button: {
    alignItems: 'center',
    backgroundColor: '#DDDDDD',
    padding: 10,
    width: 300,
    marginTop: 16,
  },
});
const Home = ({route,navigation}) => {
console.disableYellowBox = true;
  publicIP()
          .then(ip => {
                  var url = 'http://api.ipstack.com/'+ip+'?access_key=7d2446dd2b89b6bbbe347e21777e6cb5';
          fetch(url)
            .then((response) => response.json())
            .then((responseJson) => {
              db.collection('videos')
                .where('state', '==',responseJson.region_code)
                .where('lang', '==',responseJson.location.languages[0].code)
                .get()
                .then(querySnapshot => {
                  querySnapshot.forEach(documentSnapshot => {
                        videos.push(documentSnapshot.data());
                            });
                });
            })
            .catch((error) => {
              alert(responseJson.city);
             //console.error(error);
            });
          })
          .catch(error => {
            alert(responseJson.city);
            console.log(error);
            // 'Unable to get IP address.'
          });


  return (
    <>
      <StatusBar
        translucent
        backgroundColor='transparent'
        barStyle='light-content'
      />
        <Header/>

      <Container
       orientation='horizontal'
       initialPage={1}>
        <Foll key={0} navigation={navigation} route={route}/>
        <Hero key={1} videos={videos} navigation={navigation} route={route}/>
      </Container>
    </>
  )
}

export default Home
