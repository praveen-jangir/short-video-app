import firebase from 'firebase';
firebase.initializeApp(firebaseConfig = {
    apiKey: "AIzaSyBW1ubNTPY1FsO09KpkLZHa-h1do3xhu1w",
    authDomain: "kitket-645b1.firebaseapp.com",
    databaseURL: "https://kitket-645b1.firebaseio.com",
    projectId: "kitket-645b1",
    storageBucket: "kitket-645b1.appspot.com",
    messagingSenderId: "942118615188",
    appId: "1:942118615188:web:faddf3e1d35042fea8dc81",
    measurementId: "G-3EZC07X26Z"
  });
  // Initialize Firebase
  
  export default firebase;