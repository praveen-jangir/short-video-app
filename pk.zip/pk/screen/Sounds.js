import React, { Component } from 'react';
import { AUDIO_RECORDING,Audio,Sound} from 'expo-av'
import { TouchableOpacity,StyleSheet, Text, View, SafeAreaView, Image, ScrollView } from "react-native";
import {
  Container,
  Header,
  Content,
  Left,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Item,
  Input
} from 'native-base';
  import Profile from './Profile';
  import firebase from './firebase.js';
let helperArray = require('../api/sounds.json');
const source = require('./hello.mp3');
const db = firebase.firestore();
export default class Search extends Component {
  constructor(props) {
    super(props);
    this.state = {
      playingStatus: "nosound",
      allUsers: helperArray,
      usersFiltered: helperArray,
      music:"",
      play:"no",
    };

  db.collection('music')
  .get()
  .then(querySnapshot => {
    querySnapshot.forEach(documentSnapshot => {
          helperArray.push(documentSnapshot.data());
    });
  });

  }
  componentDidMount() {}
  searchUser = text => {
    this.setState({
      usersFiltered: this.state.allUsers.filter(i =>
        i.name.toLowerCase().includes(text.toLowerCase()),
      ),
    });
  };    
  render() {

function play(x) {
  const _playAndPause = async () => {
    const soundObject = new Audio.Sound();
    await soundObject.unloadAsync();
      const source = { uri:x};
        await soundObject.loadAsync(source);
        await soundObject.playAsync();
  }
  
  return _playAndPause()
  }
  function pause(x) {
  const _playAndPause = async () => {
    const soundObject = new Audio.Sound();
    await soundObject.unloadAsync();
  }
  return _playAndPause()
  }
    return (
      <Container>
        <Header style={{backgroundColor:'#fff',marginTop:35}} searchBar rounded>
          <Item>     
            <Input
              placeholder="Search Sound.."
              onChangeText={text => this.searchUser(text)}
            />
            <Icon name="ios-search"/>
          </Item>
        </Header>
        <Content>
          {this.state.usersFiltered.map(item => (
          
            <ListItem avatar>
            <TouchableOpacity>
              <Left>
                <Thumbnail source={require("../assets/avatar/01.jpg")} />
              </Left>
             </TouchableOpacity>
              <Body>
                <Text style={{ marginTop: 10 ,marginLeft: 10,fontSize:14,width:220 }}>{item.name}</Text>
          {
            this.state.play == 'no' ?<TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress={() => {play(item.music)}}>
          <Image
            //We are showing the Image from online
            source={{
              uri:
                'https://static.thenounproject.com/png/1813972-200.png',
            }}
            style={styles.ImageIconStyle}
          />
          </TouchableOpacity>:<TouchableOpacity style={styles.FacebookStyle} activeOpacity={0.5} onPress={() =>{pause(item.music)}}>
          
          <Image
            //We are showing the Image from online
            source={{
              uri:
                'https://img.pngio.com/pause-button-icon-pause-icon-button-png-and-vector-with-pause-icon-png-640_640.png',
            }}
            style={styles.ImageIconStyle}
          />
          </TouchableOpacity>
          }
         <TouchableOpacity style={styles.Facebook} activeOpacity={0.5} onPress={() => this.props.navigation.navigate('Camera',{Music:item.music,Name:item.name})}>
          
          <Image
            //We are showing the Image from online
            source={{
              uri:
                'https://cdn.iconscout.com/icon/free/png-512/plus-119-458361.png',
            }}
            style={styles.ImageIconStyle}
          />
          </TouchableOpacity>
          <Text  style={{ marginTop: -30 ,marginLeft: 10,fontSize:14,width:220,color:"#ccc" }}>{item.username}</Text>
              </Body>
            </ListItem>
          
          ))}
        </Content>
      </Container>
    );
  }
}
const styles = StyleSheet.create({

    Header:{
        backgroundColor: "#000000",
        marginTop:"200px"
    },
    FacebookStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderWidth: 0.5,
    borderColor: '#ccc',
    height: 30,
    width: 33,
    borderRadius: 5,
    margin: 5,
    marginTop:-0,
    marginLeft:180
  },
  Facebook: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderWidth: 0.5,
    borderColor: '#ccc',
    height: 30,
    width: 33,
    borderRadius: 5,
    margin: 5,
    marginTop:-35,
    marginLeft:225,
  },
  ImageIconStyle: {
    padding: 10,
    margin: 5,
    height: 25,
    width: 25,
    resizeMode: 'stretch',
  },
  TextStyle: {
    color: '#000',
    marginBottom: 4,
    marginRight: 20,
  },
  SeparatorLine: {
    backgroundColor: '#ccc',
    width: 1,
    height: 30,
  },
});