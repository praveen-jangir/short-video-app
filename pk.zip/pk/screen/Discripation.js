import React, {Component,} from 'react';
import { TouchableOpacity,StyleSheet, Text, View, SafeAreaView, Image, ScrollView,TextInput,Button } from "react-native";
import {
  Container,
  Header,
  Content,
  Left,
  Right,
  Body,
  Icon,
  ListItem,
  Thumbnail,
  Item,
  Input
} from 'native-base';
import styled from 'styled-components/native'
import publicIP from 'react-native-public-ip';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Card } from 'react-native-paper';
import Profile from './Profile';
import firebase from './firebase';
import * as VideoThumbnails from 'expo-video-thumbnails';
let helperArray = require('../api/userList.json');
export default class Disc extends Component {
  constructor(props) {
    const {videos} =props.route.params;
    console.log(videos)
    super(props);
    this.state = {
      allUsers: helperArray,
      usersFiltered: helperArray,
      text:"",
      ipAddress:'',
      state:'',
      city:'',
      lang:'',
      username:'',
      videox:videos,
      poster:'',
      loading:"not",
    };

     const { poster,videox } = this.state;
    (async () => {
    const { uri } = await VideoThumbnails.getThumbnailAsync(
        videox,
        {
          time: 0,
        }
      );
      this.setState({ poster: uri });
     })();
    publicIP()
          .then(ip => {
                  var url = 'http://api.ipstack.com/'+ip+'?access_key=7d2446dd2b89b6bbbe347e21777e6cb5';
          fetch(url)
            .then((response) => response.json())
            .then((responseJson) => {
              this.setState({
                state:responseJson.region_code,
                ipAddress:responseJson.ip,
                city:responseJson.city,
                lang:responseJson.location.languages[0].code,
              })
            })
            .catch((error) => {
             //console.error(error);
            });
          })
          .catch(error => {
            console.log(error);
            // 'Unable to get IP address.'
          }); 
    
  }
  componentDidMount() {}
  render() {
    const Upload = async() =>{
  const user = firebase.auth().currentUser;
if (user) {
  this.setState({loading:"yes"});
  async function datax(){
        firebase
        .storage()
        .ref("videos/"+name)
        .getDownloadURL()
        .then((snapshot) => {
         firebase
        .storage()
        .ref("poster/"+name)
        .getDownloadURL()
        .then((snapshot1) => {
  const db = firebase.firestore();
  const subscriber = db
      .collection('user')
      .doc(user.uid)
      .onSnapshot(documentSnapshot => {
          db.collection("videos").add({
          video: snapshot,
          name:name,
          uid: user.uid,
          disc:this.state.text,
          song:"origanl",
          username:documentSnapshot.data().username,
          city:this.state.city,
          state:this.state.state,
          lang:this.state.lang,
          ipAddress:this.state.ipAddress,
          poster:snapshot1,

      }).catch((error) => {
        alert("1")
       datax();
      })
      this.setState({loading:"no"});
      this.props.navigation.navigate("Account");
                  })
}).catch((error) => {
        alert("1")
       datax();
      });
}).catch((error) => {
        alert("1")
       datax();
      });

}
    const uri=this.state.videox;
    const res = uri.split("/");
    const sln = res.length;
    const name = res[sln-1];
    const sp =name.split(".");
    const len = sp.length;
    const music =len[len-1];
    const response =await fetch(uri);
    const response1 =await fetch(this.state.poster);
    const blob = await response.blob();
    const blob1 = await response1.blob();
    var ref = await firebase.storage().ref().child("videos/"+name);
    var ref1 = await firebase.storage().ref().child("poster/"+name);
    datax();
    return (ref.put(blob),ref1.put(blob1));    
}
else{
  this.props.navigation.navigate('Login');
}
}  
    return (
      <View style={{backgroundColor:"white",flex:1}}>
      <View style={{padding:5,backgroundColor:"white"}}>
        <Image style={{
          width:"20%",
          height:120,
          marginLeft:10,
        }} source={{uri:this.state.poster}} />
        <Body style={{marginLeft:70,marginTop:-120}}>
    <TextInput 
        multiline 
        placeholder="Write Capation here                                 "
        style={{
          maxHeight: 120, // <- set the max height here
          height: 120,
          // just some styling to make the input visible
          borderColor: "#b0afafbd", 
          borderWidth: 0.2, 
          padding: 10, 
          width: "75%",
        }} onChangeText={text => this.setState({text})}/>
        </Body>
        <View
         style={{flex:1,
          borderBottomWidth:0.5,
          marginTop:130,
          borderColor:"#b0afafbd"
         }}
        >
        </View>
        </View>

{this.state.loading == "yes" ?<Iconbb source={require('../images/loading.gif')} />:null}
        <Containerb>
      <Menub>
        <Iconb source={require('../images/draft.png')} />
      </Menub>
      <Menub>
      <TouchableOpacity onPress={Upload}>
        <Iconb source={require('../images/post.png')} />
        </TouchableOpacity>
      </Menub>
    </Containerb>
    </View>
    );
  }
}
const Iconbb = styled.Image`
  height: 100px;
  width: 100px;
  position: absolute;
`
const Containerb = styled.View`
  width: 100%;
  position: absolute;
  top: 550px;
  z-index: 1;
  justify-content: center;
  border-top-width: 0px;
  border-top-color: rgba(255, 255, 255, 0.2);
  flex-direction: row;
`
const Menub = styled.TouchableOpacity`
  width: 50%;
  height: 100%;
  justify-content: center;
  align-items: center;
`
const Iconb = styled.Image.attrs({ resizeMode: 'contain' })`
  width: 160px;
  borderRadius:4;
`
const MenuTextb = styled.Text`
  font-size: 12px;
  margin-top: 5px;
  color: ${props => (props.active ? '#fff' : 'rgba(255,255,255,0.6)')};
`
const styles = StyleSheet.create({

    Header:{
        backgroundColor: "#FFFFFF",
        marginTop:"200px"
    },
    imageThumbnail: {
    justifyContent: 'center',
    alignItems: 'center',
    height: '20%',
    width:'30%',
  },
  profileImage: {
        width: 120,
        height: 120,
        borderRadius: 80,
        overflow: "hidden"
    },
    image: {
        flex: 1,
        height: undefined,
        width: undefined,
        borderRadius:80
    },
  title: {
    textAlign: 'center',
    marginVertical: 8,
  },
  fixToText: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    bottom:-550,
  },
  separator: {
    marginVertical: 8,
    borderBottomColor: '#737373',
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
});