import React, { Component } from 'react';
//Import React
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
  SafeAreaView,
} from 'react-native';
//Import basic elements we need from React Native
import { AUDIO_RECORDING,Audio,Sound} from 'expo-av'
//Import library for Sound Component

//List of the dummy sound track
const audioList = [
  {
    title: 'Play mp3 sound from Local',
    isRequire: true,
    url:'https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/music%2FTere%20Bin%20Ab%20Na%20Lenge%20Ek%20Bhi%20Dam.mp3?alt=media&token=e958d797-0b4d-48fd-835b-ff38249b146b',
  },
  {
    title: 'Play mp3 sound from remote URL',
    url:
      'https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/music%2FTere%20Bin%20Ab%20Na%20Lenge%20Ek%20Bhi%20Dam.mp3?alt=media&token=e958d797-0b4d-48fd-835b-ff38249b146b',
  },
  {
    title: 'Play aac sound from Local',
    isRequire: true,
    url:'https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/music%2FTere%20Bin%20Ab%20Na%20Lenge%20Ek%20Bhi%20Dam.mp3?alt=media&token=e958d797-0b4d-48fd-835b-ff38249b146b',
  },
  {
    title: 'Play aac sound from remote URL',
    url:
      'https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/music%2FTere%20Bin%20Ab%20Na%20Lenge%20Ek%20Bhi%20Dam.mp3?alt=media&token=e958d797-0b4d-48fd-835b-ff38249b146b',
  },
  {
    title: 'Play wav sound from Local',
    isRequire: true,
    url: 'https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/music%2FTere%20Bin%20Ab%20Na%20Lenge%20Ek%20Bhi%20Dam.mp3?alt=media&token=e958d797-0b4d-48fd-835b-ff38249b146b',
  },
  {
    title: 'Play wav sound from remote URL',
    url:
      'https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/music%2FTere%20Bin%20Ab%20Na%20Lenge%20Ek%20Bhi%20Dam.mp3?alt=media&token=e958d797-0b4d-48fd-835b-ff38249b146b',
  },
];

var sound1='https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/music%2FTere%20Bin%20Ab%20Na%20Lenge%20Ek%20Bhi%20Dam.mp3?alt=media&token=e958d797-0b4d-48fd-835b-ff38249b146b'

function playSound() {
    sound1 = new Sound("https://firebasestorage.googleapis.com/v0/b/kitket-645b1.appspot.com/o/music%2FTere%20Bin%20Ab%20Na%20Lenge%20Ek%20Bhi%20Dam.mp3?alt=media&token=e958d797-0b4d-48fd-835b-ff38249b146b", (error, sound) => {
      if (error) {
        alert('error' + error.message);
        return;
      }
      sound1.play(() => {
        sound1.release();
      });
    });
  }

function stopSound() {
    sound1.stop(() => {
      console.log('Stop');
    });
}

function componentWillUnmount() {
  sound1.release();
}

class App extends Component {
  constructor(props) {
    super(props);
    Sound.setCategory('Playback', true); // true = mixWithOthers
    this.state = {
      tests: {},
    };
  }

  render() {
    return (
      <SafeAreaView style={{ flex: 1 }}>
        <View style={styles.container}>
          <Text style={styles.headerTitle}>
            Example to Play Music in React Native
          </Text>
          <ScrollView style={styles.container}>
            {audioList.map((item, index) => {
              return (
                <View style={styles.feature} key={item.title}>
                  <Text style={{ flex: 1, fontSize: 14 }}>{item.title}</Text>
                  <TouchableOpacity
                    onPress={() => {
                      return playSound(item, index);
                    }}>
                    <Text style={styles.buttonPlay}>Play</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => {
                      return stopSound(item, index);
                    }}>
                    <Text style={styles.buttonStop}>Stop</Text>
                  </TouchableOpacity>
                </View>
              );
            })}
          </ScrollView>
        </View>
      </SafeAreaView>
    );
  }
}

export default App;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerTitle: {
    fontSize: 16,
    color: 'white',
    fontWeight: 'bold',
    paddingVertical: 20,
    textAlign: 'center',
    backgroundColor: 'rgba(00,00,80,1)',
  },
  buttonPlay: {
    fontSize: 16,
    color: 'white',
    backgroundColor: 'rgba(00,80,00,1)',
    borderWidth: 1,
    borderColor: 'rgba(80,80,80,0.5)',
    overflow: 'hidden',
    paddingHorizontal: 15,
    paddingVertical: 7,
  },
  buttonStop: {
    fontSize: 16,
    color: 'white',
    backgroundColor: 'rgba(80,00,00,1)',
    borderWidth: 1,
    borderColor: 'rgba(80,80,80,0.5)',
    overflow: 'hidden',
    paddingHorizontal: 15,
    paddingVertical: 7,
  },
  feature: {
    flexDirection: 'row',
    padding: 10,
    alignSelf: 'stretch',
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: 'rgb(180,180,180)',
    borderBottomWidth: 1,
    borderBottomColor: 'rgb(230,230,230)',
  },
});